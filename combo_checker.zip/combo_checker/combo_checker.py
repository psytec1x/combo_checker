import argparse
import re
from collections import Counter
from tqdm import tqdm
import os

def detect_delimiter(lines):
    delimiters = [':', ';', '|', ',']
    delimiter_count = Counter()
    for line in lines:
        for delimiter in delimiters:
            delimiter_count[delimiter] += line.count(delimiter)
    return delimiter_count.most_common(1)[0][0]

def is_valid_email(email):
    return re.match(r"[^@]+@[^@]+\.[^@]+", email) is not None

def process_file(file_path, delimiter=None):
    valid_entries = set()
    invalid_entries = []
    duplicate_entries = set()
    
    with open(file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()
    
    if delimiter is None:
        delimiter = detect_delimiter(lines)
    
    for line in tqdm(lines, desc=f'Processing {file_path}'):
        line = line.strip()
        if delimiter in line:
            user, password = line.split(delimiter, 1)
            if is_valid_email(user) or (':' in user and len(user.split(':')[0]) > 0):
                entry = f"{user.lower()}{delimiter}{password}"
                if entry in valid_entries:
                    duplicate_entries.add(entry)
                else:
                    valid_entries.add(entry)
            else:
                invalid_entries.append(line)
        else:
            invalid_entries.append(line)
    
    return valid_entries, invalid_entries, duplicate_entries

def main():
    parser = argparse.ArgumentParser(description="Combo File Checker")
    parser.add_argument('files', nargs='+', help="Input file paths")
    parser.add_argument('-d', '--delimiter', help="Specify the delimiter")
    parser.add_argument('-o', '--output', help="Output file for cleaned entries")
    parser.add_argument('-i', '--invalid', help="Output file for invalid entries")
    
    args = parser.parse_args()
    
    all_valid_entries = set()
    all_invalid_entries = []
    all_duplicate_entries = set()
    
    for file_path in args.files:
        valid_entries, invalid_entries, duplicate_entries = process_file(file_path, args.delimiter)
        all_valid_entries.update(valid_entries)
        all_invalid_entries.extend(invalid_entries)
        all_duplicate_entries.update(duplicate_entries)
    
    print(f"Valid entries: {len(all_valid_entries)}")
    print(f"Invalid entries: {len(all_invalid_entries)}")
    print(f"Duplicate entries: {len(all_duplicate_entries)}")
    
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as out_file:
            for entry in all_valid_entries:
                out_file.write(f"{entry}\n")
    
    if args.invalid:
        with open(args.invalid, 'w', encoding='utf-8') as invalid_file:
            for entry in all_invalid_entries:
                invalid_file.write(f"{entry}\n")
    
    print("Processing completed.")

if __name__ == "__main__":
    main()